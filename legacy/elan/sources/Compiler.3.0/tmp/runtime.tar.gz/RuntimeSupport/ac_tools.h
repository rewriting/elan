#ifndef _ac_tools_h
#define _ac_tools_h

#include "term.h"
#include "match_state.h"
#include "bgraph.h"

extern int is_maximal_identical_element(struct termac *t, 
                                        int multiplicity,
                                        struct term **ptr_list_x);

extern void extract_maximal_identical_element(struct termac *t, 
                                              int multiplicity,
                                              struct termac **ptr_list_x,
                                              struct termac **ptr_list_y);

extern void extract_minimal_identical_element(struct termac *t, 
                                              int multiplicity,
                                              struct termac **ptr_list_x,
                                              struct termac **ptr_list_y);

extern void substitution_build(struct termac *t, match_state *ms,
                               int nb_variable, struct term *substitution[],
                               int nb_variable_ac,
                               void (*variable_extract)(),
                               int base_id_pattern);

extern void substitution_build_without_context(struct termac *t,
                                               match_state *ms,
                                               int nb_variable,
                                               struct term *substitution[],
                                               int nb_variable_ac,
                                               void (*variable_extract)(),
                                               int base_id_pattern);

extern struct termac *rest_extract(struct termac *t, match_state *ms);

extern void extract_xy_from_pe(struct termac *t, int *E, int *sol,
                               int multiplicity,
                               struct termac **ptr_list_x,
                               struct termac **ptr_list_y);

extern int minimal_extract_fail(int taille,int E[], int sol[], int multiplicity);

extern int maximal_extract_fail(int taille,int E[], int sol[], int multiplicity);

extern int next_pe_extract(int pos,int E[], int sol[], int multiplicity);

extern int next_pe_extract_fail(int pos,int E[], int sol[], int multiplicity);

extern int next_pe_extract2(int total, int pos,int E[], int sol[], int multiplicity);

extern int next_pe_extract2_fail(int total,int pos,int E[], int sol[], int multiplicity);

extern int match_subterm_AC(int base_id_pattern,
                            int no_arg_subject,
                            int *mask,
                            BG *cbg,
                            int (*my_match_subterm)(),
                            int nb_rule,
                            int **pattern_list,
                            int nb_pattern_in_cbg,
                            struct term *t,
                            int max_nb_pattern_under_AC);

#endif
