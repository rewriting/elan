import java.util.*;

public abstract class Lexem {
  protected int code;
  protected String name="<unnamed>";

  abstract void put();

  public Lexem(int code, String name) {
    this.code = code;
    this.name = name;
  }

  public int getCode() {
    return code;
  }

  public String getName() {
    return name;
  }

  public String toString() {
    // "<lex" + code + ":" + name + ">";
    if(name.equals("\\")) {
      /*
       * protection du backslash
       */
      return "\\" + name;
    } else {
      return name;
    }
  }
  
}

