import java.util.*;

public class LexemRuleName extends Lexem {
  private static Hashtable table = new Hashtable(40);

  public LexemRuleName(int code, String name) {
    super(code,name);
  }

  public void put() {
       Lexem old = (Lexem) table.put("lex" + code, this);
    if( old != null ) {
      if (Flags.warnings) {
        System.out.println("Warning: '" + old + "' and '" + this + "' have the same code");
      }
    }
  }

  public static Lexem get(int code) {
    return (Lexem)table.get("lex" + code);
  }

  public static void dump() {
    Enumeration e = table.keys();
    while(e.hasMoreElements()) {
      String key = (String) e.nextElement();
      Lexem lex = (Lexem)table.get(key);
      if (Flags.verbose) {
      System.out.println("<" + key + ":" + lex + ">"); }
    }
  }

}

